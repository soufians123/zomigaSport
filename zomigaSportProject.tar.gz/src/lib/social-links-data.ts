import type { SocialLink } from '@/types';

export const socialLinks: SocialLink[] = [
  { id: 1, name: 'WhatsApp', url: '#' },
  { id: 2, name: 'Facebook', url: '#' },
  { id: 3, name: 'Telegram', url: '#' },
];
